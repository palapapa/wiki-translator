# WikiTranslator

## Development

Run `initialize.ps1` to start development.
