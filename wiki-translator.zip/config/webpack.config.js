export let config =
{
    "entry": "dist/popup.js"
}
