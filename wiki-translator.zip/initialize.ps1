Push-Location $dir
npm install
npm run watch
Pop-Location
